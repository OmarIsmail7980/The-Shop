const {Schema,model} = require("mongoose");

const products =new Schema({
    productsName:String,
    discription:String,
    price:Number,
    image:String
})

const productsModel = model("products",products,"products");

module.exports = productsModel;