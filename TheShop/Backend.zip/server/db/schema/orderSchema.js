const {Schema,model} = require("mongoose");

const orderSchema = new Schema({
    productsName:String,
    discription:String,
    price:Number,
    image:String,
    date:{type:Date, default:Date.now()}
})

const orderModel = model("order",orderSchema);

module.exports = orderModel;