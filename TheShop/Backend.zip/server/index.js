const express = require("express");
const app = express();
const cors = require("cors")
const products = require("./routes/products");
const orders = require("./routes/cart");
const PORT = 8080;

require("./db/db");
app.use(express.json());
app.use(cors());

app.use("/orders",orders);
app.use("/products",products);



app.listen(PORT, ()=>{
    console.log("listening on port %d",PORT)
})