const {Router} = require("express");
const router = Router();
const productsModel = require("../db/schema/productsSchema")

router.get("/", async (req,res)=>{

    try{
        const response  = await productsModel.find({});
        console.log(response);
        if(response){
            res.status(200).json({status:"success",data:response})
        }else{
            res.status(404).json({status:"not found"})
        }
    }catch(error){
        res.status(500).json({status:"failure"})
    }
    
})

router.get("/:id", async (req,res)=>{

    const {params} = req;
    const {id}= params;
    console.log(id);
    try{
        const response = await productsModel.findById(id);
        if(response){
            res.status(200).json({status:"success",data:response});
        }else{
            res.status(404).json({status:"failure",message:"Not Found"})
        }
        
    }catch(error){
        res.status(500).json({status:"failure",message:"error occured"})
    }
})



module.exports = router;