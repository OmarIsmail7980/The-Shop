const {Router} = require("express");
const router = Router();
const orderModel= require("../db/schema/orderSchema")


router.post("/" ,(req,res)=>{
    try{
        const {body} = req;
        body.forEach((b)=>{
            const schema = new orderModel(b);
            const response = schema.save();
        })
        
        res.status(200).json({status:"Success", message:"Order has been placed! Thank you for Shopping with us"});
        
    }catch(error){
        res.status(500).json({status:"failure",message:"Error occured"})
    }
})

router.get("/", async(req,res)=>{
    try{
        const response = await orderModel.find({});
        if(response){
            res.status(200).json({status:"Success", data:response});
        }else{
            res.status(404).json({status:"failure", message:"Not found"})
        }
        
    }catch(error){
        res.status(500).json({status:"failure",message:"error occured"})
    }
})



module.exports = router;