import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IProducts from '../interfaces/products';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  
  
  constructor(private http: HttpClient) { 
  }

  getProducts(){
    return this.http.get("http://localhost:8080/products")
  }

  getDetails(id:String){
    return this.http.get("http://localhost:8080/products/"+id);
  }


}
