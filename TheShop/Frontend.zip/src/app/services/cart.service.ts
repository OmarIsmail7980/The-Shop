import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IOrders from '../interfaces/orders';
import IProducts from '../interfaces/products';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  cartItems:IProducts[]=[]
  constructor(private http:HttpClient) { }

  addToCart(item:IProducts){
    this.cartItems.unshift(item);
  }

  getOrders(){
    return this.http.get("http://localhost:8080/orders");
  }

  placeOrder(form:any[]){
    return this.http.post("http://localhost:8080/orders",form)
  }
}
