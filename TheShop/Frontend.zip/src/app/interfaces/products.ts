export default interface IProducts{
    _id:String,
    productName:String,
    discription:String,
    price:number,
    image:String
}