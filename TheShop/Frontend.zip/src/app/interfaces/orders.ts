export default interface IOrders{
    _id:String,
    productName:String,
    discription:String,
    price:number,
    image:String,
    date:Date
}