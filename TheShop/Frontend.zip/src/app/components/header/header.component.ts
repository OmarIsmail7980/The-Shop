import { Component, OnInit } from '@angular/core';
import IProducts from 'src/app/interfaces/products';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'sh-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {


  constructor(private cart:CartService) { }

  length:IProducts[]=[];
  
  ngOnInit(): void {
    this.length=this.cart.cartItems;
  }

}
