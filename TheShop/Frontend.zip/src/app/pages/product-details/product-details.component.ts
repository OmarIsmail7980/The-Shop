import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import IProducts from 'src/app/interfaces/products';
import { CartService } from 'src/app/services/cart.service';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'sh-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  id!:string;
  product:IProducts[]=[];
  constructor(private route:ActivatedRoute,private productServ:ProductsService,
     private cartServ:CartService, private router:Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params=>{
      this.id = params.id;
    });
    this.productServ.getDetails(this.id).subscribe((response:any)=>{
      this.product.push(response.data);
    })
  }

  addToCart(product:IProducts){
    this.cartServ.addToCart(product);
  }

  buy(){
    this.cartServ.placeOrder(this.product).subscribe((response:any)=>{
      this.router.navigateByUrl("orders");
      setTimeout(() => {
        alert(response.message);
        
      }, 200);
    })
    
  }


}
