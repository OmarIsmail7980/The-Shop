import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import IProducts from 'src/app/interfaces/products';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'sh-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private cart:CartService, private router:Router) { }

  items:IProducts[]=[]
  total:number=0;
  ngOnInit(): void {
    this.items = this.cart.cartItems;

    this.items.forEach(item => {
      this.total+=item.price;
    });
  }


  buy(){
    this.cart.placeOrder(this.items).subscribe((response:any)=>{
      this.router.navigateByUrl("orders");
      setTimeout(() => {
        alert(response.message);
        
      }, 1);
      this.cart.cartItems.length=0;
    })
    
  }

  remove(product:any){
    for(let i=0; i<this.items.length;i++){
      if(this.items[i].productName === product.productName){
        this.items.splice(i,1);
        this.total-=this.items[i].price;
      }
    }
    
  }

}
