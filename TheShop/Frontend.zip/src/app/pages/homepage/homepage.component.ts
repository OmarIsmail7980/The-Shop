import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import IProducts from 'src/app/interfaces/products';
import { CartService } from 'src/app/services/cart.service';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'sh-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  userName="";
  products:IProducts[]=[];
  constructor( private productServ:ProductsService, private router:Router, 
    private cart:CartService) { }

  ngOnInit(): void {
    // this.products = this.productServ.products;
    this.productServ.getProducts().subscribe((response:any)=>{
      this.products=response.data;
    })
  }

  getDetails(id:String){
      this.router.navigateByUrl("products/"+id);
  }

  addToCart(product:IProducts){
    this.cart.addToCart(product);
  }
}
