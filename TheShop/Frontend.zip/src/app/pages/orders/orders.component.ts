import { Component, OnInit } from '@angular/core';
import IOrders from 'src/app/interfaces/orders';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'sh-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  orders:IOrders[]=[];
  constructor(private cartServ:CartService,) { }

  ngOnInit(): void {
    this.cartServ.getOrders().subscribe((response:any)=>{
      console.log(response);
      this.orders = response.data;
    })
  }

}
